<?php
return array(
	//'配置项'=>'配置值'
	'LAYOUT_ON'             =>  'on' // 是否启用布局
);